<?php

echo nl2br("ACKNOLEDGEMENT 
 
 
The satisfaction that accompanies the successful completion of any task would be incomplete 
without the mention of people whose ceaseless cooperation made it possible, whose constant 
guidance and encouragement crown all efforts with success. 
 
We are grateful to our project guide Dr. Sourav Samanta sir for the guidance, 
inspiration and constructive suggestions that helpful us in the preparation and execution of this project. 
 
We would also express our thanks Mr. Unknown and people who have helped in successful completion of the project. \n
 
Sharik Ahmad(IT 3rd year)           
Sajan Tomar(IT 3rd Year)             
Milagroso Jose Alberto Salvador(IT 3rd year)
Valdo Paulo Pery Tivana(IT 3rd year)");

?>
<html>
<head>
	<title>About</title>
	<link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>
	<div class="skg">
		 <a href="https://www.facebook.com/sourav.samanta.7906" ><img src="ss.jpg" width="150px" height="150px"><p></a>
		 <p>Dr. Sourav Samanta </p>
		
	</div>
	
</body>
</html>