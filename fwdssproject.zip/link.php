<?php

?>
<html>
<head>
	<style>
	body{
	background: url(15.jpg);
	background-size:cover;
	background-repeat:no-repeat;
	background-position:center;
	}
	.a{
	float:left;
	padding:30px;
	position:relative;
	left:180px;
	}
	h1{
	font-family: "courier";
	position:relative;
	left:200px;
	color:black;
	
	}
	</style>
</head>
<body>
	<h1>Some Important Book Links To Download PDF</h1>
	<div class="a">
	<img src="3.jpg" width="150px" height="180px"><br>
	<a href="http://library.aceondo.net/ebooks/Computer_Science/Data_Communication_and_Networking_by_Behrouz.A.Forouzan_4th.edition.pdf" 
	class="btn">Data communications </a><br>
	<a href="http://library.aceondo.net/ebooks/Computer_Science/Data_Communication_and_Networking_by_Behrouz.A.Forouzan_4th.edition.pdf" 
	class="btn">and networking</a><br>
	<a href="http://library.aceondo.net/ebooks/Computer_Science/Data_Communication_and_Networking_by_Behrouz.A.Forouzan_4th.edition.pdf" 
	class="btn">Behrouz A. Forouzan </a></div>
	
	<div class="a">
	<img src="11.jpg" width="150px" height="180px"><br>
	<a href="https://www.blackhat.com/presentations/bh-usa-05/bh-us-05-long.pdf" class="btn">How To Own a Shadow</a><br>
	<a href="https://www.blackhat.com/presentations/bh-usa-05/bh-us-05-long.pdf" class="btn">by Jonny Long</a></div>
	
	<div class="a">
	<img src="12.jpg" width="150px" height="180px"><br>
	<a href="JavaScript Tutorial.pdf - Tutorialspoint" class="btn">JavaScript Tutorial</a><br>
	<a href="JavaScript Tutorial.pdf - Tutorialspoint" class="btn">Tutorialspoint</a></div>
	
	<div class="a">
	<img src="13.jpg" width="150px" height="180px"><br>
	<a href="http://cs.petrsu.ru/~musen/php/2013/Books/Beginning%20PHP%205.3%20by%20Matt%20Doyle.pdf" class="btn">Beginning </a><br>
	<a href="http://cs.petrsu.ru/~musen/php/2013/Books/Beginning%20PHP%205.3%20by%20Matt%20Doyle.pdf" class="btn">PHP and MY SQL</a></div>
</body>
</html>